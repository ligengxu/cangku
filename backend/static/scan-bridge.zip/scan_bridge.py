#!/usr/bin/env python3
"""
果管系统 - 扫码称重桥接服务 v2.0
运行在扫码机Windows电脑上

工作流程:
  海康读码平台扫到码 -> HTTP推送到本程序(localhost:9090)
  -> 本程序从串口秤读取当前重量
  -> 合并条码+重量 转发到果管服务器

海康读码平台配置:
  HTTP输出插件 -> URL: http://127.0.0.1:9090/scan
  方式: GET
  参数1: code = {code}
  参数2: weight = {weight}  (如果海康能拿到重量就填，否则留空由本程序从秤读)

使用: 双击运行 或 python scan_bridge.py
"""

import http.server
import urllib.parse
import urllib.request
import json
import time
import threading
import sys
import os
import socket
import ctypes

# ═══════════════════════════════════════
# 配置
# ═══════════════════════════════════════
DEFAULT_CONFIG = {
    "server": "http://36.134.229.82:8000",
    "machine": "1",
    "port": "9090",
    "scale_port": "COM3",
    "scale_baud": "9600",
    "scale_enabled": "true",
}

cfg = dict(DEFAULT_CONFIG)
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bridge.conf")

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()

def save_config():
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        for k, v in cfg.items():
            f.write(f"{k}={v}\n")

# ═══════════════════════════════════════
# 控制台颜色 (Windows)
# ═══════════════════════════════════════
def init_console():
    if sys.platform == "win32":
        try:
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            os.system("title 果管扫码桥接服务")
        except:
            pass

def color(text, code):
    return f"\033[{code}m{text}\033[0m"

def green(t): return color(t, "32")
def red(t): return color(t, "31")
def yellow(t): return color(t, "33")
def cyan(t): return color(t, "36")
def bold(t): return color(t, "1")

# ═══════════════════════════════════════
# 称重秤
# ═══════════════════════════════════════
current_weight = 0.0
weight_lock = threading.Lock()
scale_connected = False

def scale_reader():
    global current_weight, scale_connected
    try:
        import serial
    except ImportError:
        print(red("  [秤] pyserial未安装! 请运行: pip install pyserial"))
        return

    port = cfg["scale_port"]
    baud = int(cfg["scale_baud"])

    while True:
        try:
            ser = serial.Serial(port, baud, timeout=1)
            scale_connected = True
            print(green(f"  [秤] 已连接: {port} @ {baud}"))
            buf = ""
            while True:
                data = ser.read(100)
                if data:
                    buf += data.decode("ascii", errors="ignore")
                    while "\n" in buf or "\r" in buf:
                        sep = "\n" if "\n" in buf else "\r"
                        line, buf = buf.split(sep, 1)
                        line = line.strip()
                        if line:
                            nums = "".join(c for c in line if c.isdigit() or c == ".")
                            if nums:
                                try:
                                    w = float(nums)
                                    if 0 < w < 200:
                                        with weight_lock:
                                            current_weight = w
                                except ValueError:
                                    pass
        except Exception as e:
            scale_connected = False
            print(yellow(f"  [秤] 连接失败: {e}, 5秒后重试..."))
            time.sleep(5)

def get_weight():
    with weight_lock:
        return current_weight

# ═══════════════════════════════════════
# 转发到果管后端
# ═══════════════════════════════════════
stats = {"ok": 0, "fail": 0, "total": 0, "last_code": "", "last_result": ""}

def forward(code, weight):
    server = cfg["server"].rstrip("/")
    machine = cfg["machine"]
    url = f"{server}/api/device/scan-push?code={urllib.parse.quote(str(code))}&weight={weight}&metion={machine}"
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            body = json.loads(resp.read().decode())
            stats["total"] += 1
            stats["last_code"] = str(code)
            if body.get("success"):
                stats["ok"] += 1
                d = body.get("data", {})
                sku = d.get("sku_name", "")
                worker = d.get("worker_name", "")
                stats["last_result"] = f"OK: {sku} ({worker})"
                print(f"  {green('✓')} {code}  {weight}kg  -> {green(sku)}  {worker}")
            else:
                stats["fail"] += 1
                msg = body.get("message", "")
                stats["last_result"] = f"FAIL: {msg}"
                print(f"  {red('✗')} {code}  {weight}kg  -> {red(msg)}")
            return body
    except Exception as e:
        stats["fail"] += 1
        stats["total"] += 1
        stats["last_result"] = f"ERROR: {e}"
        print(f"  {red('!')} {code}  -> {red(str(e))}")
        return {"success": False, "message": str(e)}

# ═══════════════════════════════════════
# HTTP服务 - 接收海康读码平台推送
# ═══════════════════════════════════════
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)

        # 兼容多种参数名
        code = (params.get("code") or params.get("barcode") or params.get("data") or [""])[0]
        weight_str = (params.get("weight") or ["0"])[0]

        try:
            weight = float(weight_str)
        except:
            weight = 0.0

        # 如果海康没传重量(或为0)，从秤读取
        if weight <= 0 and cfg.get("scale_enabled", "true").lower() in ("true", "1"):
            weight = get_weight()

        ts = time.strftime("%H:%M:%S")
        print(f"\n  [{cyan(ts)}] 收到扫码: {bold(code)}  秤重: {weight}kg")

        if code:
            result = forward(code, weight)
        else:
            result = {"success": False, "message": "empty barcode"}
            print(f"  {red('!')} 空条码，忽略")

        resp = json.dumps(result, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(resp)

    def do_POST(self):
        self.do_GET()

    def log_message(self, *a):
        pass

# ═══════════════════════════════════════
# 心跳
# ═══════════════════════════════════════
def heartbeat():
    while True:
        try:
            url = f"{cfg['server'].rstrip('/')}/api/device/heartbeat/{cfg['machine']}"
            urllib.request.urlopen(urllib.request.Request(url, method="POST"), timeout=3)
        except:
            pass
        time.sleep(25)

# ═══════════════════════════════════════
# 状态显示
# ═══════════════════════════════════════
def status_display():
    while True:
        time.sleep(30)
        s = stats
        w = get_weight()
        sc = green("●") if scale_connected else red("●")
        print(f"\n  --- 状态 | 成功:{green(str(s['ok']))} 失败:{red(str(s['fail']))} 总计:{s['total']} | 秤{sc} {w}kg ---")

# ═══════════════════════════════════════
# 首次运行配置向导
# ═══════════════════════════════════════
def setup_wizard():
    print(bold("\n  首次运行配置:\n"))

    v = input(f"  果管服务器地址 [{cfg['server']}]: ").strip()
    if v: cfg["server"] = v

    v = input(f"  机器编号 [{cfg['machine']}]: ").strip()
    if v: cfg["machine"] = v

    v = input(f"  本地监听端口 [{cfg['port']}]: ").strip()
    if v: cfg["port"] = v

    v = input(f"  启用称重秤? (y/n) [{cfg['scale_enabled']}]: ").strip().lower()
    if v in ("y", "yes", "true", "1"):
        cfg["scale_enabled"] = "true"
        v = input(f"  秤串口号 [{cfg['scale_port']}]: ").strip()
        if v: cfg["scale_port"] = v
        v = input(f"  秤波特率 [{cfg['scale_baud']}]: ").strip()
        if v: cfg["scale_baud"] = v
    elif v in ("n", "no", "false", "0"):
        cfg["scale_enabled"] = "false"

    save_config()
    print(green("\n  配置已保存!\n"))

# ═══════════════════════════════════════
# 主程序
# ═══════════════════════════════════════
def get_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def main():
    init_console()
    load_config()

    if not os.path.exists(CONFIG_FILE):
        setup_wizard()

    ip = get_ip()
    port = int(cfg["port"])
    scale_on = cfg.get("scale_enabled", "true").lower() in ("true", "1")

    print()
    print(bold("  ╔══════════════════════════════════════════╗"))
    print(bold("  ║   🍊 果管扫码称重桥接服务 v2.0          ║"))
    print(bold("  ╚══════════════════════════════════════════╝"))
    print()
    print(f"  服务器:  {cyan(cfg['server'])}")
    print(f"  机器号:  {bold(cfg['machine'])}")
    print(f"  监听:    {cyan(f'0.0.0.0:{port}')}")
    print(f"  秤:      {green(cfg['scale_port']) if scale_on else yellow('未启用')}")
    print(f"  本机IP:  {ip}")
    print()
    print(bold("  ┌─ 海康读码平台配置 ─────────────────────┐"))
    print(f"  │ URL:  {cyan(f'http://127.0.0.1:{port}/scan')}")
    print(f"  │ 方式: GET")
    print(f"  │ 参数: code={{code}}  weight={{weight}}")
    print(bold("  └────────────────────────────────────────┘"))
    print()

    # 启动后台线程
    threading.Thread(target=heartbeat, daemon=True).start()
    threading.Thread(target=status_display, daemon=True).start()

    if scale_on:
        threading.Thread(target=scale_reader, daemon=True).start()

    # 启动HTTP服务
    try:
        server = http.server.HTTPServer(("0.0.0.0", port), Handler)
    except OSError as e:
        print(red(f"  端口 {port} 被占用! {e}"))
        print(f"  请修改 bridge.conf 中的 port 或关闭占用程序")
        input("\n  按回车退出...")
        return

    print(green(f"  等待海康读码平台推送数据...\n"))

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\n\n  {bold('退出')} | 成功:{stats['ok']} 失败:{stats['fail']} 总计:{stats['total']}")
        server.shutdown()

if __name__ == "__main__":
    main()
